<?php require "header.php"; ?>

<!-- CONTENT -->
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
    <h1 class="page-header">NBAse</h1>
    <p>NBAse is an NBA database application made for CPSC 304.</p>
    <p><a href="https://github.com/nsue/cpsc304">GitHub Page</a></p>
    <p>
        <h2 class="sub-header">Project team</h2>
        <ul>
            <li>Marvin Cadano</li>
            <li>Jacob Lee</li>
            <li>Norman Sue</li>
            <li>Daniel Tsang</li>
        </ul>
    </p>
</div>        
<!-- END CONTENT -->

<?php require "footer.php"; ?>